CREATE VIEW url_pendente AS
  SELECT
    `u`.`ID`        AS `ID`,
    `l`.`URL`       AS `URL`,
    `u`.`ID_ORIGEM` AS `ID_ORIGEM`
  FROM (`brianpl1_rastreador`.`url` `u`
    JOIN `brianpl1_rastreador`.`links` `l` ON ((`u`.`URL` = `l`.`ID`)))
  WHERE (NOT (`l`.`URL` IN (SELECT `l`.`URL`
                            FROM (`brianpl1_rastreador`.`visitas` `v`
                              JOIN `brianpl1_rastreador`.`links` `l` ON ((`v`.`ID_URL` = `l`.`ID`))))))
  ORDER BY rand()
  LIMIT 100;

